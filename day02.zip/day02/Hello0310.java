package day02;

public class Hello0310 {

	public static void main(String[] args) {
		// print 계열 메소드를 이용해 자바로 하고싶은 것 작성해서 출력 하기

		System.out.println("   .--.\r\n" + "  |o_o |\r\n" + "  |:_/ |\r\n" + " //   \\ \\\r\n" + "(|     | )\r\n"
				+ "/'\\_   _/`\\\r\n" + "\\___)=(___/");
		
		

	}

}
