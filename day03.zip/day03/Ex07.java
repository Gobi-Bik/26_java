package day03;

import java.util.Scanner;

public class Ex07 {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);

		System.out.print("점수 입력 : ");
		int inputNum = scan.nextInt();

		if (inputNum <= 100 && inputNum >= 90) {
			System.out.println("A");
		} else if (inputNum < 90 && inputNum >= 80) {
			System.out.println("B");
		} else if (inputNum < 80 && inputNum >= 70) {
			System.out.println("C");
		} else if (inputNum < 60 && inputNum >= 50) {
			System.out.println("D");
		} else if (inputNum < 50 && inputNum >= 0) {
			System.out.println("F");
		} else {
			System.out.println("0과 100 사이 입력");
		}

		scan.close();

	}

}
