package day03;

import java.util.Scanner;

public class Ex04 {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);

		System.out.print("정수 입력 : ");
		int inputNum = scan.nextInt();

		if ((inputNum % 2) == 0) {
			System.out.println("입력된 " + inputNum + "은(는) 짝수입니다.");
		} else {
			System.out.println("입력된 " + inputNum + "은(는) 홀수입니다.");
		}

		scan.close();
	}

}