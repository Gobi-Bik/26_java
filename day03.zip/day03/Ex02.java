package day03;

import java.util.Scanner;

public class Ex02 {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);

		System.out.print("정수 입력 : ");
		int inputTime = scan.nextInt();

		int sec = inputTime % 60;
		int min = (inputTime / 60) % 60;
		int hour = (inputTime / 60) / 60;

		System.out.println("입력된 " + inputTime + "초는 " + hour + "시간, " + min + "분, " + sec + "초입니다.");

		scan.close();
	}

}
