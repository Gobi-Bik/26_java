package day03;

import java.util.Scanner;

public class Ex06 {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);

		String MyId = new String("yhyhkhkh");
		int myPw = 20251318;

		System.out.print("아이디 입력 : ");
		String Id = new String(scan.next());
		System.out.print("비밀번호 입력 : ");
		int Pw = scan.nextInt();

		if (MyId.equals(Id) && myPw == Pw) {
			System.out.println("로그인 성공");
		} else {
			System.out.println("로그인 실패");
		}

		scan.close();
	}

}
