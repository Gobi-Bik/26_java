package day03;

import java.util.Scanner;

public class Ex03 {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);

		System.out.println("정수를 입력하세요 : ");
		int inputNum = scan.nextInt();

		int n = inputNum % 2; // 짝수 홀수 판단 수식
		String result = (n == 0) ? "짝수" : "홀수";

		System.out.println(inputNum + "은(는) " + result);

		scan.close();
	}

}
