package day03;

// import
import java.util.Scanner;

public class Ex01 {

	public static void main(String[] args) {
		// 변수 선언
		int age;
		String name = new String();
		double height;
		String city = new String();
		boolean marry;

		// 변수 초기화
		age = 20;
		name = "조양희";

		// Scanner 객체 생성
		Scanner scan = new Scanner(System.in);
		System.out.print("나이를 입력하세요 : ");
		age = scan.nextInt();
		System.out.print("이름을 입력하세요 : ");
		name = scan.next();
		System.out.print("키를 입력하세요 : ");
		height = scan.nextDouble();
		System.out.println("사는 도시를 입력하세요 : ");
		city = scan.next();
		System.out.println("결혼 여부(false or true 입력) : ");
		marry = scan.nextBoolean();

		// 출력
		System.out.println(
				"나이 : " + age + "\n이름 : " + name + "\n키 : " + height + "\n도시 : " + city + "\n결혼 여부 : " + marry);

		scan.close();
	}

}
