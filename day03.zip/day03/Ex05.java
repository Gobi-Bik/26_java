package day03;

import java.util.Scanner;

public class Ex05 {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);

		System.out.println("정수 입력 : ");
		int inputNum = scan.nextInt();

		if (inputNum >= 70) {
			System.out.println("합격입니다.");
		} else {
			System.out.println("불합격입니다.");
		}

		scan.close();
	}

}