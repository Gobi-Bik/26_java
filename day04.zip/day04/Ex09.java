package day04;

import java.util.Scanner;

public class Ex09 {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);

		int sum = 0;

		while (true) {
			System.out.print("정수 입력 : ");
			int input = scan.nextInt();

			if (input < 0) {
				break;
			}
			sum += input;
		}

		System.out.println("정수의 합 : " + sum);

		scan.close();
	}

}
