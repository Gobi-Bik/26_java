package day04;

import java.util.Scanner;

public class Ex07 {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);

		System.out.print("정수 입력 : ");

		int count = 0;
		int sum = 0;
		int input = scan.nextInt();

		while (input != -1) {
			sum += input;
			count++;
			System.out.print("정수 입력 : ");
			input = scan.nextInt();
		}

		double avg = (double) sum / count;

		System.out.println("합 : " + sum + ", " + count + "회 반복됨");
		System.out.println("평균 : " + avg);

		scan.close();
	}

}
