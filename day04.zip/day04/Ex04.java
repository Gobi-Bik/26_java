package day04;

import java.util.Scanner;

public class Ex04 {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);

		System.out.print("철수 가위바위보 입력 : ");
		String inputRSP1 = scan.next();
		System.out.print("영희 가위바위보 입력 : ");
		String inputRSP2 = scan.next();

		if (inputRSP1.equals(inputRSP2)) {
			System.out.println("비겼습니다.");
		}

		else {
			if (inputRSP1.equals("가위")) {
				if (inputRSP2.equals("바위")) {
					System.out.print("영희");
				} else if (inputRSP2.equals("보")) {
					System.out.print("철수");
				}
			}

			else if (inputRSP1.equals("바위")) {
				if (inputRSP2.equals("보")) {
					System.out.print("영희");
				} else if (inputRSP2.equals("가위")) {
					System.out.print("철수");
				}
			}

			else if (inputRSP1.equals("보")) {
				if (inputRSP2.equals("가위")) {
					System.out.print("영희");
				} else if (inputRSP2.equals("바위")) {
					System.out.print("철수");
				}
			}

			System.out.println(" 승리");
		}

		scan.close();
	}

}
