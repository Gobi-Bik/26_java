package day04;

import java.util.Scanner;

public class Ex03 {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);

		int balance = 10000; // 교통카드 잔액
		System.out.print("나이 입력 : ");
		int age = scan.nextInt();

		if (age >= 19) {
			balance -= 1200;
			System.out.print("어른, ");
		} else if (age >= 13) {
			balance -= 720;
			System.out.print("청소년, ");
		} else if (age >= 7) {
			balance -= 450;
			System.out.print("어린이, ");
		}

		System.out.println("현재 잔액 : " + balance);

		scan.close();
	}

}
