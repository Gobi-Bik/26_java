package day04;

public class Ex06 {

	public static void main(String[] args) {
		// 1부터 10까지의 합을 계산하는 for 반복문 완성
//		int sum = 0;
//
//		for (int i = 1; i <= 100; i++) {
//			sum += i;
//		}

		// 1부터 10까지의 합을 계산하는 while 반복문 완성
		int sum = 0;
		int i = 1;

		while (i <= 100) {
			sum += i;
			i++;
		}

		System.out.println(sum);

	}

}
