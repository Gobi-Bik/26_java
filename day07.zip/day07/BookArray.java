package day07;

import java.util.Scanner;

public class BookArray {
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);

		Book[] book = new Book[2];

		for (int i = 0; i < book.length; i++) {
			System.out.print("제목 : ");
			String title = scan.nextLine();
			System.out.print("저자 : ");
			String author = scan.nextLine();
			book[i] = new Book(title, author);
		}

		for (int i = 0; i < book.length; i++) {
			System.out.println((i + 1) + "번 째 책 제목 : " + book[i].title + " / 책 저자 : " + book[i].author);
		}

		scan.close();
	}

}
