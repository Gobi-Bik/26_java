package day05;

public class Array03 {

	public static void main(String[] args) {
		int num[] = { 1, 2, 3, 4, 5 };
		int sum = 0;

		for (int k : num) {
			sum += k;
		}

		System.out.println("합 : " + sum);
	}

}
