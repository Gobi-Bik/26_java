package day05;

import java.util.Scanner;

public class Array01 {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);

		// 1차원 배열 선언
		int intArray[];

		// 배열 생성
		intArray = new int[5];

		int max = 0;
		int sum = 0;
		double avg = 0;

		System.out.println("양수 5개를 입력");

		for (int i = 0; i < intArray.length; i++) {
			System.out.print((i + 1) + "번 정수 입력 : ");

			intArray[i] = scan.nextInt();

			sum += intArray[i];

			if (intArray[i] > max) {
				max = intArray[i];
			}
		}

		avg = (double) sum / intArray.length;

		System.out.println("가장 큰 수 : " + max);
		System.out.println("평균 : " + avg);

		scan.close();
	}
}
