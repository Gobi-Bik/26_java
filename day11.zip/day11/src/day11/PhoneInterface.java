package day11;

public interface PhoneInterface { // 인터페이스 선언
	// 상수
	final int TIMEOUT = 10000; // 상수 필드 선언

	void sendCall(); // 추상 메소드

	void receiveCall(); // 추상 메소드

	default void printLog() { // default 메소드
		System.out.println("*** phone ***");
	}

	// 추상 메소드
}
