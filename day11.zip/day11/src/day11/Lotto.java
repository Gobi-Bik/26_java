package day11;

import java.util.Random;

public class Lotto {

	public static void main(String[] args) {
		// 난수 (! ~ 45까지의 임의의 정수 6개 생성
		Random random = new Random();

		System.out.print("이번주 로또 번호 : ");

		for (int i = 0; i < 6; i++) {
			System.out.print((random.nextInt(45) + 1) + " ");
		}
	}
}