package day06;

import java.util.Scanner;

public class Add {

	public static void main(String[] args) {
		// 2개의 정수를 입력받아 더한 결과 출력

//		Scanner scan = new Scanner(System.in);
//
//		System.out.print("첫 번째 정수 입력 : ");
//		int inputNum1 = scan.nextInt();
//		System.out.print("두 번째 정수 입력 : ");
//		int inputNum2 = scan.nextInt();
//
//		int result = inputNum1 + inputNum2;
//
//		System.out.println("두 정수의 합 : " + result);

		// 2개의 실수를 입력받아 곱한 결과 출력

		Scanner scan = new Scanner(System.in);

		System.out.print("실수 입력 : ");
		double inputDoubleNum1 = scan.nextDouble();
		System.out.print("실수 입력 : ");
		double inputDoubleNum2 = scan.nextDouble();

		double DoubleResult = inputDoubleNum1 * inputDoubleNum2;

		System.out.println("두 실수의 곱 : " + DoubleResult);

		scan.close();
	}

}
