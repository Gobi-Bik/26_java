package day06;

import java.util.Scanner;

public class Method2 {
	// 2개의 정수를 입력받아 최대값을 반환하는 max()메소드를 정의하고 호출한 후 결과 출력
	public static int max(int x, int y) {
		if (x > y) {
			return x;
		} else {
			return y;
		}
	}

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);

		System.out.print("첫 번째 정수 입력 : ");
		int num1 = scan.nextInt();
		System.out.print("두 번째 정수 입력 : ");
		int num2 = scan.nextInt();

		System.out.println("최대값 : " + max(num1, num2));

		scan.close();
	}

}
