package day06;

import java.util.Scanner;

public class Method1 {
	// 1. 매개변수 X, 반환형 X -> add() 메소드
	public static void add() {
		Scanner scan = new Scanner(System.in);
		int num1 = scan.nextInt();
		int num2 = scan.nextInt();
		System.out.println(num1 + num2);
		scan.close();
	}

	// 2. 매개변수 O, 반환형 X -> add() 메소드
	public static void add(int a, int b) {
		System.out.println(a + b);
	}

	// 3. 매개변수 X, 반환형 O -> add1() 메소드
	public static int add1() {
		Scanner scan = new Scanner(System.in);
		int a = scan.nextInt();
		int b = scan.nextInt();
		scan.close();
		return a + b;
	}

	// 4. 매개변수 O, 반환형 O -> add2() 메소드
	public static int add2(int a, int b) {
		return a + b;
	}

	public static void main(String[] args) {
		// add();

		// add(50, 60);

		// System.out.println(add1());

		int result = add2(50, 100);
		System.out.println(result);
	}

}
