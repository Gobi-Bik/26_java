package day06;

import java.util.Scanner;

public class Method3 {
	// 2개의 정수와 1개의 문자를 입력받아서 4칙연산을 수행하는 계산기 메소드 add(), sub(), mul(), div()
	public static int add(int x, int y) {
		return x + y;
	}

	public static int sub(int x, int y) {
		return x - y;
	}

	public static int mul(int x, int y) {
		return x * y;
	}

	public static int div(int x, int y) {
		return x / y;
	}

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);

		System.out.print("첫 번째 정수 입력 : ");
		int a = scan.nextInt();
		System.out.print("두 번째 정수 입력 : ");
		int b = scan.nextInt();
		System.out.print("기호 입력 : ");
		char ch = scan.next().charAt(0);
		int result = 0;

		if (ch == '+') {
			result = add(a, b);
		} else if (ch == '-') {
			result = sub(a, b);
		} else if (ch == '*') {
			result = mul(a, b);
		} else if (ch == '/') {
			result = div(a, b);
		}

		System.out.println(a + " " + ch + " " + b + " " + "= " + result);

		scan.close();
	}

}
